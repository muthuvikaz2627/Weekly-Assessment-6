import { User } from './user';

describe('user', () => {
  it('should create an instance', () => {
    expect(new User()).toBeTruthy();
  });
});
